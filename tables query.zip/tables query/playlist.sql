CREATE TABLE mytable(
   genre_id INTEGER  NOT NULL PRIMARY KEY 
  ,name     VARCHAR(18) NOT NULL
);
INSERT INTO mytable(genre_id,name) VALUES (1,'Music');
INSERT INTO mytable(genre_id,name) VALUES (2,'Movies');
INSERT INTO mytable(genre_id,name) VALUES (3,'TV Shows');
INSERT INTO mytable(genre_id,name) VALUES (4,'Audiobooks');
INSERT INTO mytable(genre_id,name) VALUES (5,'90’s Music');
INSERT INTO mytable(genre_id,name) VALUES (6,'Audiobooks');
INSERT INTO mytable(genre_id,name) VALUES (7,'Movies');
INSERT INTO mytable(genre_id,name) VALUES (8,'Music');
INSERT INTO mytable(genre_id,name) VALUES (9,'Music Videos');
INSERT INTO mytable(genre_id,name) VALUES (10,'TV Shows');
INSERT INTO mytable(genre_id,name) VALUES (11,'Brazilian Music');
INSERT INTO mytable(genre_id,name) VALUES (12,'Classical');
INSERT INTO mytable(genre_id,name) VALUES (13,'Classical 101 - Deep Cuts');
INSERT INTO mytable(genre_id,name) VALUES (14,'Classical 101 - Next Steps');
INSERT INTO mytable(genre_id,name) VALUES (15,'Classical 101 - The Basics');
INSERT INTO mytable(genre_id,name) VALUES (16,'Grunge');
INSERT INTO mytable(genre_id,name) VALUES (17,'Heavy Metal Classic');
INSERT INTO mytable(genre_id,name) VALUES (18,'On-The-Go 1');
