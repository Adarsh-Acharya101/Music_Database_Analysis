CREATE TABLE mytable(
   genre_id INTEGER  NOT NULL PRIMARY KEY 
  ,name     VARCHAR(18) NOT NULL
);
INSERT INTO mytable(genre_id,name) VALUES (1,'Rock');
INSERT INTO mytable(genre_id,name) VALUES (2,'Jazz');
INSERT INTO mytable(genre_id,name) VALUES (3,'Metal');
INSERT INTO mytable(genre_id,name) VALUES (4,'Alternative & Punk');
INSERT INTO mytable(genre_id,name) VALUES (5,'Rock And Roll');
INSERT INTO mytable(genre_id,name) VALUES (6,'Blues');
INSERT INTO mytable(genre_id,name) VALUES (7,'Latin');
INSERT INTO mytable(genre_id,name) VALUES (8,'Reggae');
INSERT INTO mytable(genre_id,name) VALUES (9,'Pop');
INSERT INTO mytable(genre_id,name) VALUES (10,'Soundtrack');
INSERT INTO mytable(genre_id,name) VALUES (11,'Bossa Nova');
INSERT INTO mytable(genre_id,name) VALUES (12,'Easy Listening');
INSERT INTO mytable(genre_id,name) VALUES (13,'Heavy Metal');
INSERT INTO mytable(genre_id,name) VALUES (14,'R&B/Soul');
INSERT INTO mytable(genre_id,name) VALUES (15,'Electronica/Dance');
INSERT INTO mytable(genre_id,name) VALUES (16,'World');
INSERT INTO mytable(genre_id,name) VALUES (17,'Hip Hop/Rap');
INSERT INTO mytable(genre_id,name) VALUES (18,'Science Fiction');
INSERT INTO mytable(genre_id,name) VALUES (19,'TV Shows');
INSERT INTO mytable(genre_id,name) VALUES (20,'Sci Fi & Fantasy');
INSERT INTO mytable(genre_id,name) VALUES (21,'Drama');
INSERT INTO mytable(genre_id,name) VALUES (22,'Comedy');
INSERT INTO mytable(genre_id,name) VALUES (23,'Alternative');
INSERT INTO mytable(genre_id,name) VALUES (24,'Classical');
INSERT INTO mytable(genre_id,name) VALUES (25,'Opera');
